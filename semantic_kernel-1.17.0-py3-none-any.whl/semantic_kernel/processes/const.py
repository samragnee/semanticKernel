# Copyright (c) Microsoft. All rights reserved.

END_PROCESS_ID: str = "Microsoft.SemanticKernel.Process.EndStep"
