# Copyright (c) Microsoft. All rights reserved.

from semantic_kernel.kernel import Kernel

__version__ = "1.17.0"
__all__ = ["Kernel", "__version__"]
