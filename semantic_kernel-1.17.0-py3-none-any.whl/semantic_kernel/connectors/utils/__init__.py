# Copyright (c) Microsoft. All rights reserved.

from semantic_kernel.connectors.utils.document_loader import DocumentLoader

__all__ = ["DocumentLoader"]
