# Copyright (c) Microsoft. All rights reserved.

from semantic_kernel.connectors.memory.milvus.milvus_memory_store import (
    MilvusMemoryStore,
)

__all__ = ["MilvusMemoryStore"]
